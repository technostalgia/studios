import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { WaveformPlaylistProvider, Waveform, usePlaylistData, usePlaylistControls, usePlaybackAnimation } from '@waveform-playlist/browser';
import { useAudioTracks } from '@waveform-playlist/browser/tone';
import './style.css';

const theme = {
  backgroundColor: '#191f22', textColor: '#ecece4', waveFillColor: '#191f22',
  waveOutlineColor: '#191f22', waveProgressColor: '#27332f',
  timeColor: '#aeb9b5', timescaleBackgroundColor: '#191f22', playheadColor: '#f5e2ac',
  selectionColor: 'rgba(245,226,172,.15)', selectedTrackControlsBackground: '#26302d',
};
const clock = (seconds) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;

function TrackControls({ index, track }) {
  const { trackStates } = usePlaylistData();
  const { setTrackMute, setTrackSolo, setTrackVolume, setTrackPan } = usePlaylistControls();
  const state = trackStates[index];
  if (!state) return null;
  return <div className="track-controls" style={{ '--track-color': track.color }}>
    <div className="track-name"><span className="dot" />{track.name}</div>
    <div className="track-buttons">
      <button aria-label={`Mute ${track.name}`} aria-pressed={state.muted} onClick={() => setTrackMute(index, !state.muted)}>Mute</button>
      <button aria-label={`Solo ${track.name}`} aria-pressed={state.soloed} onClick={() => setTrackSolo(index, !state.soloed)}>Solo</button>
    </div>
    <label>Level <output>{Math.round(state.volume * 100)}%</output><input aria-label={`${track.name} level`} type="range" min="0" max="1" step="0.01" value={state.volume} onChange={(event) => setTrackVolume(index, Number(event.target.value))} /></label>
    <label>Pan <output>{state.pan === 0 ? 'Center' : `${Math.round(Math.abs(state.pan) * 100)}${state.pan < 0 ? 'L' : 'R'}`}</output><input aria-label={`${track.name} pan`} type="range" min="-1" max="1" step="0.05" value={state.pan} onChange={(event) => setTrackPan(index, Number(event.target.value))} /></label>
  </div>;
}

function Player({ session, onReset }) {
  const controls = usePlaylistControls();
  const { duration, isReady, canZoomIn, canZoomOut, masterVolume } = usePlaylistData();
  const { currentTime: restingTime, isPlaying, getPlaybackTime } = usePlaybackAnimation();
  const [currentTime, setTime] = useState(0);
  useEffect(() => { setTime(restingTime); if (!isPlaying) return; const timer = setInterval(() => setTime(getPlaybackTime()), 100); return () => clearInterval(timer); }, [isPlaying, restingTime, getPlaybackTime]);
  const [error, setError] = useState('');
  useEffect(() => { if (isReady) controls.setMasterVolume(0.4); }, [isReady]);
  async function togglePlay() {
    if (isPlaying) return controls.pause();
    try { await controls.play(currentTime >= duration ? 0 : currentTime); }
    catch { setError('Playback could not start. Try Play again, or reload this page.'); }
  }
  function reset() { controls.stop(); onReset(); }
  return <>
    <section className="transport" aria-label="Playback controls">
      <button className="primary" disabled={!isReady} onClick={togglePlay}>{isPlaying ? 'Ⅱ Pause' : '▶ Play'}</button>
      <button onClick={() => controls.stop()} disabled={!isReady}>■ Stop</button>
      <span className="time" role="timer">{clock(currentTime)} <span>/ {clock(duration)}</span></span>
      <div className="transport-right"><button disabled={!canZoomOut} aria-label="Zoom out" onClick={controls.zoomOut}>−</button><span>Zoom</span><button disabled={!canZoomIn} aria-label="Zoom in" onClick={controls.zoomIn}>+</button><button onClick={reset}>Reset mix</button></div>
    </section>
    <label className="seek-label">Playback position<input aria-label="Playback position" type="range" min="0" max={duration || 1} step="0.1" value={Math.min(currentTime, duration || 1)} onChange={(event) => controls.seekTo(Number(event.target.value))} /></label>
    <div className="waveforms"><Waveform interactiveClips={false} showFades={false} renderTrackControls={(index) => <TrackControls index={index} track={session.tracks[index]} />} /></div>
    <div className="player-bottom"><span>{isReady ? '4 tracks · changes apply to this playback' : 'Preparing waveforms…'}</span><label>Output <input aria-label="Output volume" type="range" min="0" max="0.8" step="0.01" value={masterVolume} onChange={(event) => controls.setMasterVolume(Number(event.target.value))} /></label></div>
    {error && <p className="error" role="alert">{error}</p>}
  </>;
}

function Session({ session, configs }) {
  const { tracks, loading, error } = useAudioTracks(configs);
  const [engineError, setEngineError] = useState('');
  const [epoch, setEpoch] = useState(0);
  if (error || engineError) return <p className="error" role="alert">The player could not prepare this session. Reload and try again.</p>;
  if (loading) return <p role="status">Preparing the session…</p>;
  return <WaveformPlaylistProvider key={epoch} tracks={tracks} mono waveHeight={180} controls={{ show: true, width: 210 }} timescale samplesPerPixel={8192} zoomLevels={[1024, 2048, 4096, 8192, 16384]} theme={theme} onError={(error) => setEngineError(error.message)}><Player session={session} onReset={() => setEpoch(value => value + 1)} /></WaveformPlaylistProvider>;
}


const bytes = value => Uint8Array.from(atob(value), c => c.charCodeAt(0));
const copy = {
  home: {title:'Recording, with intention.',eyebrow:'TECHNOSTALGIA STUDIOS · BLOOMINGTON, INDIANA',text:'A place for sound, collaboration, and close listening.',details:'The studio website is taking shape. Explore the pages above, or enter the committee listening room with your access code.'},
  services:{title:'Services.',eyebrow:'FROM AN IDEA TO A RECORDING',text:'Recording · Production · Mixing · Collaboration',details:'Detailed service descriptions and project information will be added here.'},
  equipment:{title:'Equipment.',eyebrow:'TOOLS & POSSIBILITIES',text:'A considered collection of recording tools.',details:'A verified equipment list, studio photographs, and session information will be added here.'},
  about:{title:'About.',eyebrow:'PRACTICE, PLACE & PEOPLE',text:'Technostalgia Studios · Kyle Fulford',details:'The studio story and a fuller biography will be added here.'},
  contact:{title:'Contact.',eyebrow:'START A CONVERSATION',text:'Let’s talk about what you’re making.',details:'Contact details will be added here. This preview does not collect messages.'}
};
function Sandbox({content}) {
  const [configs,setConfigs]=useState(null),[status,setStatus]=useState(''),[error,setError]=useState(''),[loading,setLoading]=useState(false);
  async function load(){
    let context;setLoading(true);setError('');
    try{
      context=new AudioContext({sampleRate:44100});
      const raw=content.audioKey.replace(/-/g,'+').replace(/_/g,'/');
      const key=await crypto.subtle.importKey('raw',bytes(raw+'='),'AES-GCM',false,['decrypt']);
      const decoded=[];
      for(const [index,track] of content.session.tracks.entries()){
        setStatus(`Loading ${track.name.toLowerCase()} · ${index+1} of 4`);
        const response=await fetch('./'+track.src);if(!response.ok)throw Error('A track could not be loaded. Please try again.');
        const packed=new Uint8Array(await response.arrayBuffer());
        const clear=await crypto.subtle.decrypt({name:'AES-GCM',iv:packed.slice(0,12)},key,packed.slice(12));
        decoded.push({name:track.name,color:track.color,audioBuffer:await context.decodeAudioData(clear),volume:1,startTime:0});
      }
      setConfigs(decoded);
    }catch(e){setError('The recording could not be loaded. Please reload and try again.');}
    finally{if(context)await context.close();setLoading(false);setStatus('');}
  }
  return <>
    <section className="intro"><div><p className="eyebrow">COMMITTEE LISTENING ROOM · WORKING EXAMPLE</p><h1>Sandbox<span className="title-dot">.</span></h1><p className="subtitle">Four instrumental parts. One shared recording.</p></div><div className="session-details"><span>FOUR SEPARATE PARTS</span><span>Guitars / Bass / Drums</span><span>Approx. 2 minutes</span></div></section>
    <p className="notice">Provisional demo · Original session offsets are unverified. These exports start together at 0:00.</p>
    <section className="player" aria-label="Interactive multitrack player">{configs?<Session session={content.session} configs={configs}/>:<div className="load-panel"><span className="load-icon">≋</span><h2>Step inside the recording.</h2><p>Listen together, isolate an instrument, or change the balance.</p><button className="primary" disabled={loading} onClick={load}>{loading?'Loading session…':'Load the four tracks'}</button><p className="load-status" role="status">{status||'Use headphones. Start at a comfortable listening level.'}</p>{error&&<p role="alert" className="error">{error}</p>}</div>}</section>
    <section className="listening-guide"><div><span className="guide-number">01</span><h3>Start with the whole</h3><p>Play the recording and follow its changing arrangement.</p></div><div><span className="guide-number">02</span><h3>Follow one part</h3><p>Solo an instrument. Listen for entrances, pauses, and texture.</p></div><div><span className="guide-number">03</span><h3>Change the relationship</h3><p>Adjust levels and pan. Reset mix restores the opening balance and position.</p></div></section>
  </>;
}
function App(){
  const [page,setPage]=useState(()=>location.hash.slice(1)||'home');
  const [content,setContent]=useState(null),[code,setCode]=useState(''),[error,setError]=useState(''),[unlocking,setUnlocking]=useState(false);
  useEffect(()=>{const handler=()=>{setPage(location.hash.slice(1)||'home');setError('');};window.addEventListener('hashchange',handler);return()=>window.removeEventListener('hashchange',handler);},[]);
  useEffect(()=>{document.title=(page==='home'?'Technostalgia Studios':page==='login'?'Committee access':page==='sandbox'?'Sandbox':copy[page]?.title.replace('.','')||'Listening room')+' · Technostalgia Studios';},[page]);
  async function unlock(e){
    e.preventDefault();setUnlocking(true);setError('');
    try{
      const response=await fetch('./access.json');if(!response.ok)throw Error();const data=await response.json();
      const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(code),'PBKDF2',false,['deriveKey']);
      const key=await crypto.subtle.deriveKey({name:'PBKDF2',salt:bytes(data.salt),iterations:data.iterations,hash:'SHA-256'},material,{name:'AES-GCM',length:256},false,['decrypt']);
      const clear=await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes(data.iv)},key,bytes(data.data));
      setContent(JSON.parse(new TextDecoder().decode(clear)));setCode('');location.hash='listening';
    }catch{setError('That access code could not unlock the listening room. Please try again.');}
    finally{setUnlocking(false);}
  }
  const isCommittee=['login','listening','sandbox','montenegro','nothing','nation','crayon','demo-a','demo-b'].includes(page);
  const active=copy[page]||copy.home;
  return <main>
    <header className="site-header"><a className="wordmark" href="#home">TECHNOSTALGIA<span>STUDIOS</span></a><nav aria-label="Main navigation">{['Home','Services','Equipment','About','Contact','Login'].map(label=><a key={label} href={'#'+label.toLowerCase()} aria-current={page===label.toLowerCase()?'page':undefined}>{label}</a>)}</nav></header>
    {!isCommittee?<><section className="intro studio-intro"><div><p className="eyebrow">{active.eyebrow}</p><h1>{active.title}</h1><p className="subtitle">{active.text}</p><p className="page-description">{active.details}</p>{page==='home'&&<a className="button-link primary" href="#login">Committee access <span aria-hidden="true">↗</span></a>}</div></section><section className="studio-panels"><article><p className="eyebrow">01 · MAKE</p><h2>Recording & production</h2><p>Space for performances, experiments, and developing ideas.</p><a href="#services">Explore services →</a></article><article><p className="eyebrow">02 · LISTEN</p><h2>Inside the recording</h2><p>The research companion invites close listening to individual parts and their relationships.</p><a href="#login">Enter the listening room →</a></article></section></>:!content?<section className="access-panel"><p className="eyebrow">COMMITTEE LISTENING ROOM</p><h1>Close listening<span className="title-dot">.</span></h1><p>Enter your access code to explore the recording examples.</p><form onSubmit={unlock}><label htmlFor="access-code">Access code</label><div className="access-input"><input id="access-code" type="password" autoComplete="off" required value={code} onChange={e=>setCode(e.target.value)}/><button className="primary" disabled={unlocking}>{unlocking?'Unlocking…':'Enter listening room'}</button></div>{error&&<p className="error" role="alert">{error}</p>}</form></section>:<>
      <div className="committee-heading"><span>RESEARCH COMPANION</span><button onClick={()=>{setContent(null);setCode('');location.hash='login';}}>Lock listening room</button></div>
      <nav className="example-nav" aria-label="Recording examples"><a href="#listening" aria-current={page==='listening'?'page':undefined}>Overview</a>{content.examples.map(example=><a key={example.id} href={'#'+example.id} aria-current={page===example.id?'page':undefined}>{example.title}</a>)}</nav>
      {page==='sandbox'?<Sandbox content={content}/>:page==='listening'||page==='login'?<><section className="intro"><div><p className="eyebrow">RECORDING BLOOMINGTON</p><h1>Listen from within<span className="title-dot">.</span></h1><p className="subtitle">Explore the parts, decisions, and relationships within a recording.</p></div></section><section className="example-grid">{content.examples.map(example=><a className="example-card" key={example.id} href={'#'+example.id}><span className="eyebrow">{example.id==='sandbox'?'READY TO EXPLORE':'FORTHCOMING'}</span><h2>{example.title}</h2><p>{example.description||'This listening example is being prepared.'}</p><span>{example.id==='sandbox'?'Open multitrack player →':'View placeholder →'}</span></a>)}</section></>:<section className="intro placeholder"><div><p className="eyebrow">LISTENING EXAMPLE · FORTHCOMING</p><h1>{content.examples.find(e=>e.id===page)?.title||'Listening example'}</h1><p className="subtitle">This recording example is being prepared.</p><p className="page-description">Context, listening prompts, and authorized media will appear here.</p><a className="button-link" href="#sandbox">Try the working Sandbox →</a></div></section>}
    </>}
    <footer><span>Technostalgia Studios · Kyle Fulford · Bloomington, Indiana</span><span>{isCommittee?'Interactive audio powered by Waveform Playlist':'Studio website preview'}</span></footer>
  </main>;
}
createRoot(document.getElementById('root')).render(<App />);
