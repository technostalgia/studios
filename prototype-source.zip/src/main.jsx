import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { WaveformPlaylistProvider, Waveform, usePlaylistData, usePlaylistControls, usePlaybackAnimation, usePlaylistState } from '@waveform-playlist/browser';
import { useAudioTracks, useDynamicEffects, useTrackDynamicEffects } from '@waveform-playlist/browser/tone';
import './style.css';
import colorLegend from '../COLOR_LEGEND.json';

const theme = {
  backgroundColor: '#191f22', textColor: '#ecece4', waveFillColor: '#191f22',
  waveOutlineColor: '#191f22', waveProgressColor: '#27332f',
  timeColor: '#aeb9b5', timescaleBackgroundColor: '#191f22', playheadColor: '#f5e2ac',
  selectionColor: 'rgba(245,226,172,.15)', selectedTrackControlsBackground: '#26302d',
};
const PLAYER_ZOOM_LEVELS = [1024,2048,4096,8192,16384];
const PLAYER_CONTROLS = {show:true,width:210};
const clock = (seconds) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;

function TrackControls({ index, track }) {
  const { trackStates } = usePlaylistData();
  const { setTrackMute, setTrackSolo, setTrackVolume, setTrackPan } = usePlaylistControls();
  const state = trackStates[index];
  if (!state) return null;
  return <div className="track-controls" style={{ '--track-color': track.color }}>
    <div className="track-name"><span className="dot" />{track.name}</div>
    <div className="track-buttons">
      <button aria-label={`Mute ${track.name}`} aria-pressed={state.muted} onClick={() => setTrackMute(index, !state.muted)}>Mute</button>
      <button aria-label={`Solo ${track.name}`} aria-pressed={state.soloed} onClick={() => setTrackSolo(index, !state.soloed)}>Solo</button>
    </div>
    <label>Level <output>{Math.round(state.volume * 100)}%</output><input aria-label={`${track.name} level`} type="range" min="0" max="1" step="0.01" value={state.volume} onChange={(event) => setTrackVolume(index, Number(event.target.value))} /></label>
    <label>Pan <output>{state.pan === 0 ? 'Center' : `${Math.round(Math.abs(state.pan) * 100)}${state.pan < 0 ? 'L' : 'R'}`}</output><input aria-label={`${track.name} pan`} type="range" min="-1" max="1" step="0.05" value={state.pan} onChange={(event) => setTrackPan(index, Number(event.target.value))} /></label>
  </div>;
}

function Player({ session, onReset, laneHeight, setLaneHeight }) {
  const controls = usePlaylistControls();
  const { duration, isReady, canZoomIn, canZoomOut, masterVolume } = usePlaylistData();
  const { currentTime: restingTime, isPlaying, getPlaybackTime, currentTimeRef } = usePlaybackAnimation();
  const [currentTime, setTime] = useState(0);
  useEffect(() => { setTime(restingTime); if (!isPlaying) return; const timer = setInterval(() => setTime(getPlaybackTime()), 100); return () => clearInterval(timer); }, [isPlaying, restingTime, getPlaybackTime]);
  const [error, setError] = useState('');
  const {isLoopEnabled, loopStart, loopEnd, selectionStart, selectionEnd, isAutomaticScroll} = usePlaylistState();
  useEffect(() => { if (duration > 0) controls.setLoopRegion(0, duration); }, [duration]);
  useEffect(() => { if (isReady) controls.setMasterVolume(0.4); }, [isReady]);
  async function play() {
    const start = isLoopEnabled && (currentTime < loopStart || currentTime >= loopEnd) ? loopStart : currentTime >= duration ? 0 : currentTime;
    try { await controls.play(start); setError(''); }
    catch { setError('Playback could not start. Try Play again, or reload this page.'); }
  }
  function stop() { controls.stop(); controls.setCurrentTime(0); }
  function loopBoundary(which, value) {
    const n = Number(value); if (!Number.isFinite(n)) return;
    if (which === 'start') controls.setLoopRegion(Math.max(0, Math.min(n, loopEnd - 0.1)), loopEnd);
    else controls.setLoopRegion(loopStart, Math.min(duration, Math.max(n, loopStart + 0.1)));
  }
  function reset() { controls.stop(); onReset(); }
  return <>
    <section className="transport daw-transport" aria-label="Playback controls">
      <div className="transport-buttons">
        <button aria-label="Go to beginning" title="Go to beginning" disabled={!isReady} onClick={() => controls.seekTo(0)}>⏮ <span>Start</span></button>
        <button aria-label="Rewind 10 seconds" title="Back 10 seconds" disabled={!isReady} onClick={() => controls.seekTo(Math.max(0, currentTimeRef.current - 10))}>⏪ <span>10s</span></button>
        <button className="primary" aria-label="Play" disabled={!isReady || isPlaying} onClick={play}>▶ Play</button>
        <button aria-label="Pause" disabled={!isReady || !isPlaying} onClick={controls.pause}>Ⅱ Pause</button>
        <button aria-label="Stop" disabled={!isReady} onClick={stop}>■ Stop</button>
        <button aria-label="Fast forward 10 seconds" title="Forward 10 seconds" disabled={!isReady} onClick={() => controls.seekTo(Math.min(duration, currentTimeRef.current + 10))}>⏩ <span>10s</span></button>
        <button aria-label="Go to end" title="Go to end" disabled={!isReady} onClick={() => controls.seekTo(duration)}>⏭ <span>End</span></button>
        <button className="loop-button" aria-label="Loop playback" aria-pressed={isLoopEnabled} disabled={!isReady} onClick={() => controls.setLoopEnabled(!isLoopEnabled)}>↻ Loop</button>
      </div>
      <span className="time" role="timer">{clock(currentTime)} <span>/ {clock(duration)}</span></span>
    </section>
    <div className="view-controls"><label><input type="checkbox" checked={isAutomaticScroll} onChange={e=>controls.setAutomaticScroll(e.target.checked)}/> Auto-scroll</label><label className="height-control">Track height <input aria-label="Track height" type="range" min="180" max="360" step="20" value={laneHeight} onChange={e=>setLaneHeight(Number(e.target.value))}/><output>{laneHeight}px</output></label><div className="zoom-control"><button disabled={!canZoomOut} aria-label="Zoom out" onClick={controls.zoomOut}>−</button><span>Zoom</span><button disabled={!canZoomIn} aria-label="Zoom in" onClick={controls.zoomIn}>+</button></div><button onClick={reset}>Reset mix</button></div>
    <fieldset className="loop-controls"><legend>Loop region</legend><label>Start (seconds)<input aria-label="Loop start seconds" type="number" min="0" max={Math.max(0,loopEnd-0.1)} step="0.1" value={Number(loopStart.toFixed(1))} onChange={e=>loopBoundary('start',e.target.value)}/></label><label>End (seconds)<input aria-label="Loop end seconds" type="number" min={loopStart+0.1} max={duration} step="0.1" value={Number(loopEnd.toFixed(1))} onChange={e=>loopBoundary('end',e.target.value)}/></label><button disabled={selectionEnd-selectionStart<0.1} onClick={()=>controls.setLoopRegionFromSelection()}>Use selection</button><button onClick={()=>controls.setLoopRegion(0,duration)}>Full recording</button><span>Drag across a waveform to select a passage, then choose Use selection.</span></fieldset>
    <label className="seek-label">Playback position<input aria-label="Playback position" type="range" min="0" max={duration || 1} step="0.1" value={Math.min(currentTime, duration || 1)} onChange={(event) => controls.seekTo(Number(event.target.value))} /></label>
    <div className="waveforms"><Waveform interactiveClips={false} showFades={false} renderTrackControls={(index) => <TrackControls index={index} track={session.tracks[index]} />} /></div>
    <div className="player-bottom"><span>{isReady ? '4 tracks · changes apply to this playback' : 'Preparing waveforms…'}</span><label>Output <input aria-label="Output volume" type="range" min="0" max="0.8" step="0.01" value={masterVolume} onChange={(event) => controls.setMasterVolume(Number(event.target.value))} /></label></div>
    {error && <p className="error" role="alert">{error}</p>}
    <details className="color-legend"><summary>Track color legend</summary><div>{Object.entries(colorLegend).map(([label,color])=><span key={label}><i style={{background:color.hex}}/>{label.replaceAll('_',' ')} · {color.name}</span>)}</div></details>
  </>;
}


function EffectsPanel({tracks, master, perTrack}) {
  const [target,setTarget]=useState('master'),[chosen,setChosen]=useState('reverb'),[error,setError]=useState('');
  const isMaster=target==='master';
  const active=isMaster?master.activeEffects:perTrack.trackEffectsState.get(target)||[];
  const selectedTrack=tracks.find(t=>t.id===target);
  const add=()=>{try{if(isMaster)master.addEffect(chosen);else perTrack.addEffectToTrack(target,chosen);setError('');}catch(e){setError('This effect could not be added. Try a different effect.');}};
  const update=(id,name,value)=>isMaster?master.updateParameter(id,name,value):perTrack.updateTrackEffectParameter(target,id,name,value);
  const bypass=id=>isMaster?master.toggleBypass(id):perTrack.toggleBypass(target,id);
  const remove=id=>isMaster?master.removeEffect(id):perTrack.removeEffectFromTrack(target,id);
  return <section className="effects-panel" aria-label="Audio effects">
    <div className="effects-title"><div><p className="eyebrow">EXPERIMENT WITH THE SOUND</p><h2>Effects rack</h2></div><span>Live playback · Original files stay intact</span></div>
    <p className="effects-help">Choose a track or the full mix, then add an effect. Start with Reverb or Feedback Delay and adjust Mix to hear the change. Bypass compares the processed sound with the original signal.</p>
    <div className="effects-toolbar"><label>Apply to<select aria-label="Effects target" value={target} onChange={e=>{setTarget(e.target.value);setError('');}}><option value="master">Full mix</option>{tracks.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select></label><label>Effect<select aria-label="Choose effect" value={chosen} onChange={e=>setChosen(e.target.value)}>{['reverb','delay','modulation','distortion','filter','dynamics','spatial'].map(category=><optgroup key={category} label={category[0].toUpperCase()+category.slice(1)}>{master.availableEffects.filter(f=>f.category===category).map(f=><option key={f.id} value={f.id}>{f.name}</option>)}</optgroup>)}</select></label><button className="primary" onClick={add}>Add effect</button><button disabled={!active.length} onClick={()=>isMaster?master.clearAllEffects():perTrack.clearTrackEffects(target)}>Clear this rack</button></div>
    <p className="rack-label">{selectedTrack?.name||'Full mix'} · {active.length} {active.length===1?'effect':'effects'} · Applied in the order shown</p>
    {!active.length&&<p className="empty-rack">No effects on this target. Add one above to start exploring.</p>}
    {active.map((effect,index)=><article className={'effect-card'+(effect.bypassed?' bypassed':'')} key={effect.instanceId} data-effect-id={effect.effectId}>
      <div className="effect-heading"><div><span className="effect-number">{String(index+1).padStart(2,'0')}</span><h3>{effect.definition.name}</h3></div><div><button aria-label={'Bypass '+effect.definition.name} aria-pressed={effect.bypassed} onClick={()=>bypass(effect.instanceId)}>{effect.bypassed?'Bypassed':'Bypass'}</button><button aria-label={'Remove '+effect.definition.name} onClick={()=>remove(effect.instanceId)}>Remove</button></div></div>
      <p>{effect.definition.description}</p><div className="effect-parameters">{effect.definition.parameters.map(param=><label key={param.name}>{param.label}<output>{typeof effect.params[param.name]==='number'?Number(effect.params[param.name].toFixed(2)):String(effect.params[param.name])}{param.unit?' '+param.unit:''}</output>{param.type==='select'?<select aria-label={effect.definition.name+' '+param.label} value={effect.params[param.name]} onChange={e=>update(effect.instanceId,param.name,typeof param.default==='number'?Number(e.target.value):e.target.value)}>{param.options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select>:param.type==='boolean'?<input aria-label={effect.definition.name+' '+param.label} type="checkbox" checked={Boolean(effect.params[param.name])} onChange={e=>update(effect.instanceId,param.name,e.target.checked)}/>:<input aria-label={effect.definition.name+' '+param.label} type="range" min={param.min} max={param.max} step={param.step||0.01} value={effect.params[param.name]} onChange={e=>update(effect.instanceId,param.name,Number(e.target.value))}/>}</label>)}</div>
    </article>)}
    {error&&<p className="error" role="alert">{error}</p>}
  </section>;
}
function SessionEngine({session, configs, onReset}) {
  const {tracks,loading,error}=useAudioTracks(configs);
  const master=useDynamicEffects(),perTrack=useTrackDynamicEffects();
  const wiredTracks=useMemo(()=>tracks.map(track=>({...track,effects:perTrack.getTrackEffectsFunction(track.id)})),[tracks,perTrack.getTrackEffectsFunction]);
  const [engineError,setEngineError]=useState('');
  const [laneHeight,setLaneHeight]=useState(180);
  const handleEngineError=useCallback(error=>setEngineError(error.message),[]);
  if(error||engineError)return <p className="error" role="alert">The player could not prepare this session. Reload and try again.</p>;
  if(loading)return <p role="status">Preparing the session…</p>;
  return <WaveformPlaylistProvider tracks={wiredTracks} effects={master.masterEffects} mono waveHeight={laneHeight} controls={PLAYER_CONTROLS} timescale samplesPerPixel={8192} zoomLevels={PLAYER_ZOOM_LEVELS} theme={theme} onError={handleEngineError}><Player session={session} onReset={onReset} laneHeight={laneHeight} setLaneHeight={setLaneHeight}/><EffectsPanel tracks={tracks} master={master} perTrack={perTrack}/></WaveformPlaylistProvider>;
}
function Session({session,configs}) {
  const [epoch,setEpoch]=useState(0);
  return <SessionEngine key={epoch} session={session} configs={configs} onReset={()=>setEpoch(v=>v+1)}/>;
}

const bytes = value => Uint8Array.from(atob(value), c => c.charCodeAt(0));
const copy = {
  home: {title:'Recording, with intention.',eyebrow:'TECHNOSTALGIA STUDIOS · BLOOMINGTON, INDIANA',text:'A place for sound, collaboration, and close listening.',details:'The studio website is taking shape. Explore the pages above, or enter the committee listening room with your access code.'},
  services:{title:'Services.',eyebrow:'FROM AN IDEA TO A RECORDING',text:'Recording · Production · Mixing · Collaboration',details:'Detailed service descriptions and project information will be added here.'},
  equipment:{title:'Equipment.',eyebrow:'TOOLS & POSSIBILITIES',text:'A considered collection of recording tools.',details:'A verified equipment list, studio photographs, and session information will be added here.'},
  about:{title:'About.',eyebrow:'PRACTICE, PLACE & PEOPLE',text:'Technostalgia Studios · Kyle Fulford',details:'The studio story and a fuller biography will be added here.'},
  contact:{title:'Contact.',eyebrow:'START A CONVERSATION',text:'Let’s talk about what you’re making.',details:'Contact details will be added here. This preview does not collect messages.'}
};
function Sandbox({content}) {
  const [configs,setConfigs]=useState(null),[status,setStatus]=useState('Loading the recording…'),[error,setError]=useState(''),[loading,setLoading]=useState(true);
  const alive=useRef(true),request=useRef(null);
  useEffect(()=>{alive.current=true;load();return()=>{alive.current=false;request.current?.abort();};},[]);
  async function load(){
    let context;const controller=new AbortController();request.current=controller;setLoading(true);setError('');
    try{
      context=new AudioContext({sampleRate:44100});
      const raw=content.audioKey.replace(/-/g,'+').replace(/_/g,'/');
      const key=await crypto.subtle.importKey('raw',bytes(raw+'='),'AES-GCM',false,['decrypt']);
      const decoded=[];
      for(const [index,track] of content.session.tracks.entries()){
        if(!alive.current||controller.signal.aborted)return;
        setStatus(`Loading ${track.name.toLowerCase()} · ${index+1} of 4`);
        const response=await fetch('./'+track.src,{signal:controller.signal});if(!response.ok)throw Error('A track could not be loaded. Please try again.');
        const packed=new Uint8Array(await response.arrayBuffer());
        const clear=await crypto.subtle.decrypt({name:'AES-GCM',iv:packed.slice(0,12)},key,packed.slice(12));
        decoded.push({name:track.name,color:track.color,audioBuffer:await context.decodeAudioData(clear),volume:1,startTime:0});
      }
      if(alive.current&&!controller.signal.aborted)setConfigs(decoded);
    }catch(e){if(alive.current&&!controller.signal.aborted)setError('The recording could not be loaded. Please try again.');}
    finally{if(context)await context.close();if(alive.current){setLoading(false);setStatus('');}}
  }
  return <>
    <section className="intro"><div><p className="eyebrow">COMMITTEE LISTENING ROOM · WORKING EXAMPLE</p><h1>Sandbox<span className="title-dot">.</span></h1><p className="subtitle">Four instrumental parts. One shared recording.</p></div><div className="session-details"><span>FOUR SEPARATE PARTS</span><span>Guitars / Bass / Drums</span><span>Approx. 2 minutes</span></div></section>
    <p className="notice">Provisional demo · Original session offsets are unverified. These exports start together at 0:00.</p>
    <section className="player" aria-label="Interactive multitrack player">{configs?<Session session={content.session} configs={configs}/>:<div className="load-panel"><span className="load-icon">≋</span><h2>{loading?'Loading the recording…':'The recording is not ready.'}</h2><p>Waveforms load automatically. Press Play when you are ready to listen.</p>{!loading&&<button className="primary" onClick={load}>Retry loading</button>}<p className="load-status" role="status">{status||'Use headphones. Start at a comfortable listening level.'}</p>{error&&<p role="alert" className="error">{error}</p>}</div>}</section>
    <section className="listening-guide"><div><span className="guide-number">01</span><h3>Start with the whole</h3><p>Play the recording and follow its changing arrangement.</p></div><div><span className="guide-number">02</span><h3>Follow one part</h3><p>Solo an instrument. Listen for entrances, pauses, and texture.</p></div><div><span className="guide-number">03</span><h3>Change the relationship</h3><p>Adjust levels and pan. Reset mix restores the opening balance and position, and removes all effects.</p></div></section>
  </>;
}
function App(){
  const [page,setPage]=useState(()=>location.hash.slice(1)||'home');
  const [content,setContent]=useState(null),[code,setCode]=useState(''),[error,setError]=useState(''),[unlocking,setUnlocking]=useState(false);
  useEffect(()=>{const handler=()=>{setPage(location.hash.slice(1)||'home');setError('');};window.addEventListener('hashchange',handler);return()=>window.removeEventListener('hashchange',handler);},[]);
  useEffect(()=>{document.title=(page==='home'?'Technostalgia Studios':page==='login'?'Committee access':page==='sandbox'?'Sandbox':copy[page]?.title.replace('.','')||'Listening room')+' · Technostalgia Studios';},[page]);
  async function unlock(e){
    e.preventDefault();setUnlocking(true);setError('');
    try{
      const response=await fetch('./access.json');if(!response.ok)throw Error();const data=await response.json();
      const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(code),'PBKDF2',false,['deriveKey']);
      const key=await crypto.subtle.deriveKey({name:'PBKDF2',salt:bytes(data.salt),iterations:data.iterations,hash:'SHA-256'},material,{name:'AES-GCM',length:256},false,['decrypt']);
      const clear=await crypto.subtle.decrypt({name:'AES-GCM',iv:bytes(data.iv)},key,bytes(data.data));
      setContent(JSON.parse(new TextDecoder().decode(clear)));setCode('');location.hash='listening';
    }catch{setError('That access code could not unlock the listening room. Please try again.');}
    finally{setUnlocking(false);}
  }
  const isCommittee=['login','listening','sandbox','montenegro','nothing','nation','crayon','demo-a','demo-b'].includes(page);
  const active=copy[page]||copy.home;
  return <main>
    <header className="site-header"><a className="wordmark" href="#home">TECHNOSTALGIA<span>STUDIOS</span></a><nav aria-label="Main navigation">{['Home','Services','Equipment','About','Contact','Login'].map(label=><a key={label} href={'#'+label.toLowerCase()} aria-current={page===label.toLowerCase()?'page':undefined}>{label}</a>)}</nav></header>
    {!isCommittee?<><section className="intro studio-intro"><div><p className="eyebrow">{active.eyebrow}</p><h1>{active.title}</h1><p className="subtitle">{active.text}</p><p className="page-description">{active.details}</p>{page==='home'&&<a className="button-link primary" href="#login">Committee access <span aria-hidden="true">↗</span></a>}</div></section><section className="studio-panels"><article><p className="eyebrow">01 · MAKE</p><h2>Recording & production</h2><p>Space for performances, experiments, and developing ideas.</p><a href="#services">Explore services →</a></article><article><p className="eyebrow">02 · LISTEN</p><h2>Inside the recording</h2><p>The research companion invites close listening to individual parts and their relationships.</p><a href="#login">Enter the listening room →</a></article></section></>:!content?<section className="access-panel"><p className="eyebrow">COMMITTEE LISTENING ROOM</p><h1>Close listening<span className="title-dot">.</span></h1><p>Enter your access code to explore the recording examples.</p><form onSubmit={unlock}><label htmlFor="access-code">Access code</label><div className="access-input"><input id="access-code" type="password" autoComplete="off" required value={code} onChange={e=>setCode(e.target.value)}/><button className="primary" disabled={unlocking}>{unlocking?'Unlocking…':'Enter listening room'}</button></div>{error&&<p className="error" role="alert">{error}</p>}</form></section>:<>
      <div className="committee-heading"><span>RESEARCH COMPANION</span><button onClick={()=>{setContent(null);setCode('');location.hash='login';}}>Lock listening room</button></div>
      <nav className="example-nav" aria-label="Recording examples"><a href="#listening" aria-current={page==='listening'?'page':undefined}>Overview</a>{content.examples.map(example=><a key={example.id} href={'#'+example.id} aria-current={page===example.id?'page':undefined}>{example.title}</a>)}</nav>
      {page==='sandbox'?<Sandbox content={content}/>:page==='listening'||page==='login'?<><section className="intro"><div><p className="eyebrow">RECORDING BLOOMINGTON</p><h1>Listen from within<span className="title-dot">.</span></h1><p className="subtitle">Explore the parts, decisions, and relationships within a recording.</p></div></section><section className="example-grid">{content.examples.map(example=><a className="example-card" key={example.id} href={'#'+example.id}><span className="eyebrow">{example.id==='sandbox'?'READY TO EXPLORE':'FORTHCOMING'}</span><h2>{example.title}</h2><p>{example.description||'This listening example is being prepared.'}</p><span>{example.id==='sandbox'?'Open multitrack player →':'View placeholder →'}</span></a>)}</section></>:<section className="intro placeholder"><div><p className="eyebrow">LISTENING EXAMPLE · FORTHCOMING</p><h1>{content.examples.find(e=>e.id===page)?.title||'Listening example'}</h1><p className="subtitle">This recording example is being prepared.</p><p className="page-description">Context, listening prompts, and authorized media will appear here.</p><a className="button-link" href="#sandbox">Try the working Sandbox →</a></div></section>}
    </>}
    <footer><span>Technostalgia Studios · Kyle Fulford · Bloomington, Indiana</span><span>{isCommittee?'Interactive audio powered by Waveform Playlist':'Studio website preview'}</span></footer>
  </main>;
}
createRoot(document.getElementById('root')).render(<App />);
