import { defineConfig } from 'vite';

// Waveform Playlist 16.0.1 exposes track colors but uses a global canvas theme.
// Scope the existing renderer to each track without changing audio processing.
export default defineConfig({
  base: './',
  build: { assetsDir: '' },
  worker: {format:'es',rollupOptions:{output:{entryFileNames:'[name]-[hash].js',chunkFileNames:'[name]-[hash].js',assetFileNames:'[name]-[hash][extname]'}}},
  optimizeDeps: { include: ['react', 'react-dom', 'react-dom/client', 'react/jsx-runtime', 'styled-components'], exclude: ['@waveform-playlist/browser'] },
  plugins: [{
    name: 'per-track-waveform-colors',
    enforce: 'pre',
    transform(source, id) {
      if(id.includes('@waveform-playlist/spectrogram/dist/index.mjs')) return {code:source.replaceAll('new URL("@dawcore/spectrogram/worker/spectrogram.worker", import.meta.url)','new URL("/node_modules/@dawcore/spectrogram/dist/worker/spectrogram.worker.mjs", import.meta.url)'),map:null};
      if (!id.includes('@waveform-playlist/browser/dist/index.mjs')) return;
      const target = /ChannelWithProgress,\s*\{\s*index: channelIndex,/;
      if (!target.test(source)) throw new Error('Waveform color integration needs review for this player version.');
      source = source.replace(target, `ColoredChannelWithProgress, { trackIndex, trackColor: track.color, index: channelIndex,`);
      source += `
function ColoredChannelWithProgress({trackIndex, trackColor, ...props}) {
  const {trackStates} = usePlaylistData();
  const state = trackStates[trackIndex];
  const anySolo = trackStates.some(track => track.soloed);
  const dimmed = state?.muted || (anySolo && !state?.soloed);
  const color = trackColor || '#6bb89d';
  return jsx(ThemeProvider, {
    theme: outer => ({...outer, waveformDrawMode:'normal', waveOutlineColor:color,
      selectedWaveOutlineColor:color, waveFillColor:'#191f22', selectedWaveFillColor:'#242e2a',
      waveProgressColor:color + '22'}),
    children: jsx('div', {style:{opacity:dimmed ? .28 : 1, transition:'opacity 150ms',
      boxShadow:state?.soloed ? 'inset 0 0 0 1px '+color : undefined},
      'data-waveform-color':color, 'data-waveform-dimmed':Boolean(dimmed),
      children:jsx(ChannelWithProgress, props)})
  });
}
`;
      return {code:source,map:null};
    }
  }]
});
